import mongoose, { Document, Schema } from 'mongoose';
import { Equipo } from '../interfaces/equipo.interface';

export interface EquipoDoc extends Equipo, Document {}

const EquipoSchema: Schema = new Schema({
  nombre: { type: String, required: true, unique: true, trim: true },
  ciudad: { type: String, required: true },
  estadio: { type: String },
  entrenador: { type: String },
  fundacion: { type: Number, min: 1850, max: new Date().getFullYear() }
}, { timestamps: true });

export default mongoose.model<EquipoDoc>('Equipo', EquipoSchema);