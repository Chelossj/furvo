import { Request, Response } from 'express';
import { validationResult } from 'express-validator';
import EquipoModel from '../models/equipo.model';

export const crearEquipo = async (req: Request, res: Response) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

  try {
    const equipo = new EquipoModel(req.body);
    await equipo.save();
    return res.status(201).json(equipo);
  } catch (err: any) {
    if (err.code === 11000) { // duplicado (unique)
      return res.status(409).json({ error: 'Ya existe un equipo con ese nombre' });
    }
    return res.status(500).json({ error: err.message || 'Error al crear equipo' });
  }
};

export const listarEquipos = async (_req: Request, res: Response) => {
  try {
    const equipos = await EquipoModel.find().sort({ nombre: 1 });
    return res.json(equipos);
  } catch (err: any) {
    return res.status(500).json({ error: err.message || 'Error al listar equipos' });
  }
};

export const obtenerEquipo = async (req: Request, res: Response) => {
  try {
    const equipo = await EquipoModel.findById(req.params.id);
    if (!equipo) return res.status(404).json({ error: 'Equipo no encontrado' });
    return res.json(equipo);
  } catch (err: any) {
    return res.status(500).json({ error: err.message || 'Error al obtener equipo' });
  }
};

export const actualizarEquipo = async (req: Request, res: Response) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

  try {
    const equipo = await EquipoModel.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true,
    });
    if (!equipo) return res.status(404).json({ error: 'Equipo no encontrado' });
    return res.json(equipo);
  } catch (err: any) {
    if (err.code === 11000) {
      return res.status(409).json({ error: 'Nombre de equipo ya en uso' });
    }
    return res.status(500).json({ error: err.message || 'Error al actualizar equipo' });
  }
};

export const eliminarEquipo = async (req: Request, res: Response) => {
  try {
    const equipo = await EquipoModel.findByIdAndDelete(req.params.id);
    if (!equipo) return res.status(404).json({ error: 'Equipo no encontrado' });
    return res.json({ message: 'Equipo eliminado' });
  } catch (err: any) {
    return res.status(500).json({ error: err.message || 'Error al eliminar equipo' });
  }
};