import { Router } from 'express';
import { body } from 'express-validator';
import { crearEquipo, listarEquipos, obtenerEquipo, actualizarEquipo, eliminarEquipo } from '../controllers/equipo.controller';

const router = Router();

const validations = [
  body('nombre').isString().trim().notEmpty().withMessage('Nombre requerido'),
  body('ciudad').isString().trim().notEmpty().withMessage('Ciudad requerida'),
  body('fundacion').optional().isInt({ min: 1850, max: new Date().getFullYear() })
];

router.post('/', validations, crearEquipo);
router.get('/', listarEquipos);
router.get('/:id', obtenerEquipo);
router.put('/:id', validations, actualizarEquipo);
router.delete('/:id', eliminarEquipo);

export default router;