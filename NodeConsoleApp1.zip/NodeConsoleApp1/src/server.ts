import express from 'express';
import mongoose from 'mongoose';
import dotenv from 'dotenv';
import cors from 'cors';
import path from 'path';
import equipoRoutes from './routes/equipo.routes';

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

// Servir archivos est�ticos desde la carpeta "public" (ruta absoluta)
const publicPath = path.join(__dirname, '..', 'public');
app.use(express.static(publicPath));

app.use('/api/equipos', equipoRoutes);

const MONGO_URI = process.env.MONGO_URI;
const PORT = Number(process.env.PORT) || 3000;

if (!MONGO_URI) {
  console.error('Falta la variable de entorno MONGO_URI. Rellena .env o exporta la variable.');
  process.exit(1);
}

async function start() {
  try {
    await mongoose.connect(MONGO_URI, { serverSelectionTimeoutMS: 5000 });
    console.log('Conectado a MongoDB Atlas');
    app.listen(PORT, () => console.log(`API en http://localhost:${PORT}`));
  } catch (err) {
    console.error('Error conexi�n MongoDB:', err);
    process.exit(1);
  }
}

start();

// Fallback: devolver index.html para cualquier ruta no API (opcional para SPA)
app.get('*', (req, res, next) => {
  if (req.path.startsWith('/api/')) return next();
  res.sendFile(path.join(publicPath, 'index.html'), (err) => {
    if (err) next(err);
  });
});

// Cerrar conexi�n de forma ordenada
process.on('SIGINT', async () => {
  await mongoose.connection.close();
  process.exit(0);
});