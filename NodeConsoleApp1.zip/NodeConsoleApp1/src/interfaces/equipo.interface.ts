export interface Equipo {
  _id?: string;
  nombre: string;
  ciudad: string;
  estadio?: string;
  entrenador?: string;
  fundacion?: number;
  createdAt?: Date;
  updatedAt?: Date;
}