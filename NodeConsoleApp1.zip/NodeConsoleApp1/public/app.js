const apiBase = '/api/equipos';
const form = document.getElementById('equipoForm');
const messageEl = document.getElementById('message');
const submitBtn = document.getElementById('submitBtn');
const cancelBtn = document.getElementById('cancelBtn');

function showMessage(text, ok = true, ms = 3500) {
  messageEl.innerHTML = '<div class="msg ' + (ok ? 'ok' : 'err') + '">' + text + '</div>';
  if (ms) setTimeout(() => messageEl.innerHTML = '', ms);
}

async function fetchEquipos() {
  try {
    const res = await fetch(apiBase);
    const data = await res.json();
    renderTable(data);
  } catch (err) {
    showMessage('Error obteniendo equipos: ' + (err.message || err), false);
  }
}

function renderTable(equipos = []) {
  const tbody = document.querySelector('#equiposTable tbody');
  tbody.innerHTML = '';
  if (!equipos.length) {
    tbody.innerHTML = '<tr><td colspan="6">No hay equipos</td></tr>';
    return;
  }
  equipos.forEach(e => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${escapeHtml(e.nombre || '')}</td>
      <td>${escapeHtml(e.ciudad || '')}</td>
      <td>${escapeHtml(e.estadio || '')}</td>
      <td>${escapeHtml(e.entrenador || '')}</td>
      <td>${e.fundacion || ''}</td>
      <td class="actions">
        <button class="edit" data-id="${e._id}">Editar</button>
        <button class="delete" data-id="${e._id}">Eliminar</button>
      </td>`;
    tbody.appendChild(tr);
  });
  tbody.querySelectorAll('button.edit').forEach(b => b.addEventListener('click', onEdit));
  tbody.querySelectorAll('button.delete').forEach(b => b.addEventListener('click', onDelete));
}

function escapeHtml(s) {
  if (!s) return '';
  return String(s).replace(/[&<>"']/g, (m) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
}

async function onEdit(e) {
  const id = e.currentTarget.dataset.id;
  try {
    const res = await fetch(apiBase + '/' + id);
    if (!res.ok) throw new Error('No encontrado');
    const equipo = await res.json();
    fillForm(equipo);
  } catch (err) {
    showMessage('Error cargando equipo: ' + (err.message || err), false);
  }
}

function fillForm(e) {
  document.getElementById('equipoId').value = e._id || '';
  document.getElementById('nombre').value = e.nombre || '';
  document.getElementById('ciudad').value = e.ciudad || '';
  document.getElementById('estadio').value = e.estadio || '';
  document.getElementById('entrenador').value = e.entrenador || '';
  document.getElementById('fundacion').value = e.fundacion || '';
  submitBtn.textContent = 'Guardar cambios';
  cancelBtn.style.display = 'inline-block';
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function resetForm() {
  form.reset();
  document.getElementById('equipoId').value = '';
  submitBtn.textContent = 'Crear equipo';
  cancelBtn.style.display = 'none';
}

async function onDelete(e) {
  if (!confirm('�Eliminar este equipo?')) return;
  const id = e.currentTarget.dataset.id;
  try {
    const res = await fetch(apiBase + '/' + id, { method: 'DELETE' });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || 'Error al eliminar');
    }
    showMessage('Equipo eliminado');
    fetchEquipos();
  } catch (err) {
    showMessage('Error al eliminar: ' + (err.message || err), false);
  }
}

form.addEventListener('submit', async (ev) => {
  ev.preventDefault();
  const id = document.getElementById('equipoId').value.trim();
  const payload = {
    nombre: document.getElementById('nombre').value.trim(),
    ciudad: document.getElementById('ciudad').value.trim(),
    estadio: document.getElementById('estadio').value.trim() || undefined,
    entrenador: document.getElementById('entrenador').value.trim() || undefined,
    fundacion: Number(document.getElementById('fundacion').value) || undefined
  };

  if (!payload.nombre || !payload.ciudad) {
    showMessage('Nombre y ciudad son obligatorios', false);
    return;
  }

  try {
    let res;
    if (id) {
      res = await fetch(apiBase + '/' + id, {
        method: 'PUT',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify(payload)
      });
    } else {
      res = await fetch(apiBase, {
        method: 'POST',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify(payload)
      });
    }
    const data = await res.json();
    if (!res.ok) {
      const errMsg = data?.error || (data?.errors && data.errors.map(x=>x.msg).join(', ')) || 'Error';
      throw new Error(errMsg);
    }
    showMessage(id ? 'Equipo actualizado' : 'Equipo creado');
    resetForm();
    fetchEquipos();
  } catch (err) {
    showMessage(err.message || 'Error', false);
  }
});

cancelBtn.addEventListener('click', () => resetForm());

// carga inicial
fetchEquipos();