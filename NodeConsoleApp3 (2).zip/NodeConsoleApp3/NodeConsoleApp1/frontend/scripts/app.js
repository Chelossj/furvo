﻿const apiBase = 'http://localhost:3000/api/equipos';
let equipoActualId = null;

// --- CRUD de equipos ---
async function fetchEquipos() {
  try {
    console.log('📡 Llamando a fetchEquipos...');
    const res = await fetch(apiBase);
    const equipos = await res.json();
    console.log('📋 Datos recibidos:', equipos);
    renderTable(equipos);
  } catch (err) {
    console.error('Error obteniendo equipos:', err);
  }
}

function renderTable(equipos) {
  const tbody = document.querySelector('#equiposTable tbody');
  tbody.innerHTML = '';

  if (!equipos || equipos.length === 0) {
    tbody.innerHTML = '<tr><td colspan="6">No hay equipos</td></tr>';
    return;
  }

  equipos.forEach(e => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${e.nombre}</td>
      <td>${e.ciudad}</td>
      <td>${e.estadio || ''}</td>
      <td>${e.entrenador || ''}</td>
      <td>${e.fundacion || ''}</td>
      <td>
        <button onclick="mostrarJugadores('${e._id}')">Jugadores</button>
        <button onclick="editarEquipo('${e._id}')">Editar</button>
        <button onclick="eliminarEquipo('${e._id}')">Eliminar</button>
      </td>
    `;
    tbody.appendChild(tr);
  });
}

document.getElementById('equipoForm').addEventListener('submit', async (e) => {
  e.preventDefault();

  const nombre = document.getElementById('nombre').value;
  const ciudad = document.getElementById('ciudad').value;
  const estadio = document.getElementById('estadio').value;
  const entrenador = document.getElementById('entrenador').value;
  const fundacion = document.getElementById('fundacion').value;

  try {
    const res = await fetch(apiBase, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ nombre, ciudad, estadio, entrenador, fundacion })
    });

    if (!res.ok) throw new Error('Error al crear equipo');

    await fetchEquipos();
    e.target.reset();
  } catch (err) {
    console.error('Error creando equipo:', err);
  }
});

async function editarEquipo(id) {
  const nombre = prompt("Nuevo nombre del equipo:");
  const ciudad = prompt("Nueva ciudad:");
  const estadio = prompt("Nuevo estadio:");
  const entrenador = prompt("Nuevo entrenador:");
  const fundacion = prompt("Nuevo año de fundación:");

  try {
    const res = await fetch(`${apiBase}/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ nombre, ciudad, estadio, entrenador, fundacion })
    });

    if (!res.ok) throw new Error('Error al editar equipo');
    fetchEquipos();
  } catch (err) {
    console.error('Error editando equipo:', err);
  }
}

async function eliminarEquipo(id) {
  try {
    await fetch(`${apiBase}/${id}`, { method: 'DELETE' });
    fetchEquipos();
  } catch (err) {
    console.error('Error eliminando equipo:', err);
  }
}

// --- Gestión de jugadores ---
async function mostrarJugadores(id) {
  equipoActualId = id;
  document.getElementById('jugadoresSection').style.display = 'block';

  try {
    const res = await fetch(`${apiBase}/${id}`);
    const equipo = await res.json();
    renderJugadoresTable(equipo.jugadores || []);
  } catch (err) {
    console.error('Error obteniendo jugadores:', err);
  }
}

function renderJugadoresTable(jugadores) {
  const tbody = document.querySelector('#jugadoresTable tbody');
  tbody.innerHTML = '';

  if (!jugadores || jugadores.length === 0) {
    tbody.innerHTML = '<tr><td colspan="5">No hay jugadores</td></tr>';
    return;
  }

  jugadores.forEach((j, index) => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${j.nombre}</td>
      <td>${j.posicion || ''}</td>
      <td>${j.dorsal || ''}</td>
      <td>${j.edad || ''}</td>
      <td><button onclick="eliminarJugador(${index})">Eliminar</button></td>
    `;
    tbody.appendChild(tr);
  });
}

document.getElementById('jugadorForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const jugadorNombre = document.getElementById('jugadorNombre').value;
  const jugadorPosicion = document.getElementById('jugadorPosicion').value;
  const jugadorDorsal = document.getElementById('jugadorDorsal').value;
  const jugadorEdad = document.getElementById('jugadorEdad').value;

  try {
    const res = await fetch(`${apiBase}/${equipoActualId}/jugadores`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ 
        nombre: jugadorNombre, 
        posicion: jugadorPosicion, 
        dorsal: jugadorDorsal, 
        edad: jugadorEdad 
      })
    });

    if (!res.ok) throw new Error('Error al agregar jugador');

    mostrarJugadores(equipoActualId);
    e.target.reset();
  } catch (err) {
    console.error('Error agregando jugador:', err);
  }
});

async function eliminarJugador(index) {
  try {
    await fetch(`${apiBase}/${equipoActualId}/jugadores/${index}`, { method: 'DELETE' });
    mostrarJugadores(equipoActualId);
  } catch (err) {
    console.error('Error eliminando jugador:', err);
  }
}

fetchEquipos();
