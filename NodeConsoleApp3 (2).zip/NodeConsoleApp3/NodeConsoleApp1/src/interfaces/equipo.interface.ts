﻿export interface Jugador {
    _id?: string;
    nombre: string;
    posicion: string;
    dorsal: number;
    edad: number;
    createdAt?: Date;
    updatedAt?: Date;
}

export interface Equipo {
    _id?: string;
    nombre: string;
    ciudad: string;
    estadio?: string;
    entrenador?: string;
    fundacion?: number;
    jugadores?: Jugador[];   // 👈 NUEVO
    createdAt?: Date;
    updatedAt?: Date;
}
