import { Router } from 'express';
import { body } from 'express-validator';
import { crearEquipo, listarEquipos, obtenerEquipo, actualizarEquipo, eliminarEquipo,agregarJugador,eliminarJugador } from '../controllers/equipo.controller';

const router = Router();

const validations = [
  body('nombre').isString().trim().notEmpty().withMessage('Nombre requerido'),
  body('ciudad').isString().trim().notEmpty().withMessage('Ciudad requerida'),
  body('fundacion').optional().isInt({ min: 1850, max: new Date().getFullYear() })
];

router.post('/', validations, crearEquipo);
router.get('/', listarEquipos);
router.get('/:id', obtenerEquipo);
router.put('/:id', validations, actualizarEquipo);
router.delete('/:id', eliminarEquipo);
router.post(
    '/:id/jugadores',
    [
        body('nombre').isString().notEmpty(),
        body('posicion').isString().notEmpty(),
        body('dorsal').isInt({ min: 1 }),
        body('edad').isInt({ min: 15 })
    ],
    agregarJugador
);
router.delete('/:id/jugadores/:jugadorId', eliminarJugador);
export default router;