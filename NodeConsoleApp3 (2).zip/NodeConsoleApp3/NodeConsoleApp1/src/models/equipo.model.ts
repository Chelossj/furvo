﻿import mongoose, { Document, Schema } from 'mongoose';
import { Equipo } from '../interfaces/equipo.interface';

export interface EquipoDoc extends Equipo, Document {}

const JugadorSchema = new Schema<Jugador>({
    nombre: { type: String, required: true },
    posicion: { type: String, required: true },
    dorsal: { type: Number, required: true },
    edad: { type: Number, required: true }
}, { timestamps: true });

const EquipoSchema: Schema = new Schema({
    nombre: { type: String, required: true, unique: true, trim: true },
    ciudad: { type: String, required: true },
    estadio: { type: String },
    entrenador: { type: String },
    fundacion: { type: Number, min: 1850, max: new Date().getFullYear() },
    jugadores: { type: [JugadorSchema], default: [] }   // 👈 NUEVO
}, { timestamps: true });
export default mongoose.model<EquipoDoc>('Equipo', EquipoSchema);