const mongoose = require('mongoose');

const EquipoSchema = new mongoose.Schema({
  nombre: String,
  ciudad: String,
  estadio: String,
  entrenador: String,
  fundacion: Number,
  jugadores: [{
    nombre: String,
    posicion: String,
    dorsal: Number,
    edad: Number
  }]
}, { timestamps: true });

module.exports = mongoose.model('Equipo', EquipoSchema);
