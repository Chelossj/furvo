const express = require('express');
const router = express.Router();
const Equipo = require('../models/Equipo');

// Obtener todos los equipos
router.get('/', async (req, res) => {
  const equipos = await Equipo.find();
  res.json(equipos);
});

// Crear equipo
router.post('/', async (req, res) => {
  const equipo = new Equipo(req.body);
  await equipo.save();
  res.json(equipo);
});

// Eliminar equipo
router.delete('/:id', async (req, res) => {
  await Equipo.findByIdAndDelete(req.params.id);
  res.json({ message: 'Equipo eliminado' });
});

// Obtener un equipo con jugadores
router.get('/:id', async (req, res) => {
  const equipo = await Equipo.findById(req.params.id);
  res.json(equipo);
});

// Agregar jugador
router.post('/:id/jugadores', async (req, res) => {
  const equipo = await Equipo.findById(req.params.id);
  equipo.jugadores.push(req.body);
  await equipo.save();
  res.json(equipo);
});

// Eliminar jugador
router.delete('/:id/jugadores/:index', async (req, res) => {
  try {
    const equipo = await Equipo.findById(req.params.id);
    const index = parseInt(req.params.index);

    if (!equipo || !Array.isArray(equipo.jugadores)) {
      return res.status(404).json({ error: 'Equipo o lista de jugadores no encontrada' });
    }

    if (index < 0 || index >= equipo.jugadores.length) {
      return res.status(400).json({ error: '�ndice de jugador inv�lido' });
    }

    equipo.jugadores.splice(index, 1);
    await equipo.save();
    res.json(equipo);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
