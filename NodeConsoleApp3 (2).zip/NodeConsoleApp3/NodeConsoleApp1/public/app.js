﻿const apiBase = '/api/equipos';
const form = document.getElementById('equipoForm');
const messageEl = document.getElementById('message');
const submitBtn = document.getElementById('submitBtn');
const cancelBtn = document.getElementById('cancelBtn');

function showMessage(text, ok = true, ms = 3500) {
  messageEl.innerHTML = '<div class="msg ' + (ok ? 'ok' : 'err') + '">' + text + '</div>';
  if (ms) setTimeout(() => messageEl.innerHTML = '', ms);
}

async function fetchEquipos() {
    console.log('Ejecutando fetchEquipos...'); 
    try {
    const res = await fetch(apiBase);
    const data = await res.json();
    console.log('Equipos recibidos:', data);
    renderTable(data);
  } catch (err) {
    showMessage('Error obteniendo equipos: ' + (err.message || err), false);
  }
}

function renderTable(equipos = []) {
  const tbody = document.querySelector('#equiposTable tbody');
  tbody.innerHTML = '';
  if (!equipos.length) {
    tbody.innerHTML = '<tr><td colspan="6">No hay equipos</td></tr>';
    return;
  }
  equipos.forEach(e => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
        <td>${e.nombre}</td>
      <td>${e.ciudad}</td>
      <td>${e.estadio || ''}</td>
      <td>${e.entrenador || ''}</td>
      <td>${e.fundacion || ''}</td>
      <td class="actions">
        <button onclick="mostrarJugadores('${e._id}')">Jugadores</button>
        <button class="delete" onclick="eliminarEquipo('${e._id}')">Eliminar</button>
      </td>
    `;
    tbody.appendChild(tr);
  });
  tbody.querySelectorAll('button.edit').forEach(b => b.addEventListener('click', onEdit));
  tbody.querySelectorAll('button.delete').forEach(b => b.addEventListener('click', onDelete));
}

function escapeHtml(s) {
  if (!s) return '';
  return String(s).replace(/[&<>"']/g, (m) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
}

async function onEdit(e) {
  const id = e.currentTarget.dataset.id;
  try {
    const res = await fetch(apiBase + '/' + id);
    if (!res.ok) throw new Error('No encontrado');
    const equipo = await res.json();
    fillForm(equipo);
  } catch (err) {
    showMessage('Error cargando equipo: ' + (err.message || err), false);
  }
}

function fillForm(e) {
  document.getElementById('equipoId').value = e._id || '';
  document.getElementById('nombre').value = e.nombre || '';
  document.getElementById('ciudad').value = e.ciudad || '';
  document.getElementById('estadio').value = e.estadio || '';
  document.getElementById('entrenador').value = e.entrenador || '';
  document.getElementById('fundacion').value = e.fundacion || '';
  submitBtn.textContent = 'Guardar cambios';
  cancelBtn.style.display = 'inline-block';
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function resetForm() {
  form.reset();
  document.getElementById('equipoId').value = '';
  submitBtn.textContent = 'Crear equipo';
  cancelBtn.style.display = 'none';
}

async function onDelete(e) {
  if (!confirm('¿Eliminar este equipo?')) return;
  const id = e.currentTarget.dataset.id;
  try {
    const res = await fetch(apiBase + '/' + id, { method: 'DELETE' });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || 'Error al eliminar');
    }
    showMessage('Equipo eliminado');
    fetchEquipos();
  } catch (err) {
    showMessage('Error al eliminar: ' + (err.message || err), false);
  }
}

form.addEventListener('submit', async (ev) => {
  ev.preventDefault();
  const id = document.getElementById('equipoId').value.trim();
  const payload = {
    nombre: document.getElementById('nombre').value.trim(),
    ciudad: document.getElementById('ciudad').value.trim(),
    estadio: document.getElementById('estadio').value.trim() || undefined,
    entrenador: document.getElementById('entrenador').value.trim() || undefined,
    fundacion: Number(document.getElementById('fundacion').value) || undefined
  };

  if (!payload.nombre || !payload.ciudad) {
    showMessage('Nombre y ciudad son obligatorios', false);
    return;
  }

  try {
    let res;
    if (id) {
      res = await fetch(apiBase + '/' + id, {
        method: 'PUT',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify(payload)
      });
    } else {
      res = await fetch(apiBase, {
        method: 'POST',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify(payload)
      });
    }
    const data = await res.json();
    if (!res.ok) {
      const errMsg = data?.error || (data?.errors && data.errors.map(x=>x.msg).join(', ')) || 'Error';
      throw new Error(errMsg);
    }
    showMessage(id ? 'Equipo actualizado' : 'Equipo creado');
    resetForm();
    fetchEquipos();
  } catch (err) {
    showMessage(err.message || 'Error', false);
  }
});

cancelBtn.addEventListener('click', () => resetForm());
function mostrarJugadores(equipoId) {
    // Mostrar la sección y formulario
    document.getElementById('jugadoresSection').style.display = 'block';
    document.getElementById('jugadorForm').style.display = 'block';
    document.getElementById('jugadorEquipoId').value = equipoId;

    // Llamar a la función que ya tienes
    fetchJugadores(equipoId);
}

async function fetchJugadores(equipoId) {
    try {
        const res = await fetch(`${apiBase}/${equipoId}`);
        const equipo = await res.json();
        renderJugadoresTable(equipo); // 👈 nueva función para pintar la tabla de jugadores
    } catch (err) {
        showMessage('Error obteniendo jugadores: ' + (err.message || err), false);
    }
}

async function addJugador(equipoId, jugador) {
    try {
        await fetch(`${apiBase}/${equipoId}/jugadores`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(jugador)
        });
        fetchJugadores(equipoId);
        showMessage('Jugador agregado correctamente');
    } catch (err) {
        showMessage('Error agregando jugador: ' + (err.message || err), false);
    }
}

async function deleteJugador(equipoId, jugadorId) {
    try {
        await fetch(`${apiBase}/${equipoId}/jugadores/${jugadorId}`, { method: 'DELETE' });
        fetchJugadores(equipoId);
        showMessage('Jugador eliminado correctamente');
    } catch (err) {
        showMessage('Error eliminando jugador: ' + (err.message || err), false);
    }
}

// Renderizar tabla de jugadores (similar a renderTable)
function renderJugadoresTable(equipo) {
    const tbody = document.querySelector('#jugadoresTable tbody');
    tbody.innerHTML = '';

    if (!equipo.jugadores || equipo.jugadores.length === 0) {
        tbody.innerHTML = '<tr><td colspan="5">No hay jugadores</td></tr>';
        return;
    }

    equipo.jugadores.forEach(j => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
      <td>${j.nombre}</td>
      <td>${j.posicion || ''}</td>
      <td>${j.dorsal || ''}</td>
      <td>${j.edad || ''}</td>
      <td class="actions">
        <button class="delete" onclick="deleteJugador('${equipo._id}','${j._id}')">Eliminar</button>
      </td>
    `;
        tbody.appendChild(tr);
    });
}
document.getElementById('jugadorForm').addEventListener('submit', async (e) => {
    e.preventDefault();

    const equipoId = document.getElementById('jugadorEquipoId').value;
    const nombre = document.getElementById('jugadorNombre').value;
    const posicion = document.getElementById('jugadorPosicion').value;
    const dorsal = document.getElementById('jugadorDorsal').value;
    const edad = document.getElementById('jugadorEdad').value;

    try {
        const res = await fetch(`${apiBase}/${equipoId}/jugadores`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ nombre, posicion, dorsal, edad })
        });

        if (!res.ok) throw new Error('Error al agregar jugador');

        showMessage('Jugador agregado correctamente', true);

        // refrescar la lista de jugadores
        fetchJugadores(equipoId);

        // limpiar formulario
        e.target.reset();
    } catch (err) {
        showMessage('Error agregando jugador: ' + (err.message || err), false);
    }
});

fetchEquipos();

